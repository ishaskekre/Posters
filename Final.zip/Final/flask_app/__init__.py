# 3rd-party packages
from flask import Flask, render_template, request, redirect, url_for
from flask_mongoengine import MongoEngine
from flask_login import LoginManager, current_user, login_user, logout_user, login_required
from flask_bcrypt import Bcrypt
from werkzeug.utils import secure_filename
from flask_talisman import Talisman
from flask_mail import Mail, Message
# stdlib
import os
from datetime import datetime

app = Flask(__name__)
app.config.update(
	DEBUG=True,
	#EMAIL SETTINGS
	MAIL_SERVER='smtp.gmail.com',
	MAIL_PORT=465,
	MAIL_USE_SSL=True,
	MAIL_USERNAME = 'hgavin2019@gmail.com',
	MAIL_PASSWORD = 'Darkbro98@0',
	)
mail = Mail(app)
csp = {
    'script-src': '\'self\''
}
Talisman(app, content_security_policy=csp)
app.config["MONGODB_Host"] = "mongodb://localhost:27017/Final"
#app.config['MONGODB_HOST'] = 'mongodb://heroku_wdzzxxj2:u4o51fsjdkguhan1gffb2hd5gh@ds121960.mlab.com:21960/heroku_wdzzxxj2?retryWrites=false'
app.config['SECRET_KEY'] = b'\x020;yr\x91\x11\xbe"\x9d\xc1\x14\x91\xadf\xec'

# mongo = PyMongo(app)
db = MongoEngine(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
bcrypt = Bcrypt(app)

from . import routes