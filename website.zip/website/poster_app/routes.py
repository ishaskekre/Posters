# 3rd-party packages
from flask import render_template, request, redirect, url_for, flash, Response
from flask_mongoengine import MongoEngine
from flask_login import LoginManager, current_user, login_user, logout_user, login_required
from flask_bcrypt import Bcrypt
from werkzeug.utils import secure_filename
from flask_mail import Mail, Message
# stdlib
from datetime import datetime
import random
import string
# local
from . import app, bcrypt, mail
from .forms import (PostForm, CommentForm, LikeForm, RegistrationForm, LoginForm,
							 UpdateUsernameForm, TFAForm)
from .models import User, Post, Comment, Like, load_user
from .utils import current_time
import flask
""" ************ View functions ************ """
@app.route('/', methods=['GET'])
def index():
	topics = ['Comedy', 'Movies', 'Weather', 'Sports', 'Miscellaneous']
	return render_template('index.html',topics = topics)

@app.route('/topics/<topic>', methods=['GET', 'POST'])
def topics(topic):
	if topic != 'Comedy' and topic != 'Movies' and topic != 'Weather' and topic != 'Sports' and topic != 'Miscellaneous':
		return render_template('topics.html', error_msg='Invalid Topic')

	posts = Post.objects(topic=topic)
	return render_template('topics.html',topic = topic, posts = posts)

@app.route('/posts/<title>', methods=['GET', 'POST'])
def post_detail(title):
	post = Post.objects(title=title).first()
	if post is None:
			return render_template('post_detail.html', error_msg='Post does not exist')
	form1 = CommentForm()
	form2 = LikeForm()
	if form1.validate_on_submit():
		comment = Comment(
			commenter=load_user(current_user.username), 
			content=form1.text.data, 
			date=current_time(),
			title=title
		)

		comment.save()

		return redirect(request.path)

	if form2.validate_on_submit():
		post.modify(likes= post.likes+1)
		post.save()
		like = Like(username = current_user.username, title = title)
		like.save()
		return redirect(request.path)

	comments = Comment.objects(title=title)

	print(current_user.is_authenticated)
	if current_user.is_authenticated:
		like = Like.objects(username = current_user.username, title = title).first()
		if like is None:
			return render_template('post_detail.html', form1=form1, form2 = form2, post=post, comments=comments)
	return render_template('post_detail.html', form1=form1, post=post, comments=comments)

@app.route('/user/<username>')
def user_detail(username):
	user = User.objects(username=username).first()
	if user is not None:
		return render_template('user_detail.html', username=username, posts = Post.objects(poster=user))
	else:
		return 'Invalid Username'


""" ************ User Management views ************ """
@app.route('/register', methods=['GET', 'POST'])
def register():
	if current_user.is_authenticated:
		return redirect(url_for('index'))

	form = RegistrationForm()
	if form.validate_on_submit():
		hashed = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
		ran = ''.join([random.choice(string.ascii_letters + string.digits) for n in range(8)])
		return redirect(url_for('TFAreg', username = form.username.data, email = form.email.data, password = hashed, ran = ran))
	
	return render_template('register.html', form=form)

@app.route('/TFAreg/<username>/<email>/<password>/<ran>', methods=['GET', 'POST'])
def TFAreg(username,email,password, ran):
	if current_user.is_authenticated:
		return redirect(url_for('index'))
	form = TFAForm()
	if flask.request.method == 'GET':
		msg = Message("Verify Code", sender="hgavin2019@gmail.com", recipients=[email])
		msg.body = "Verification code: "  + str(abs(hash(ran)))       
		mail.send(msg)
	if form.validate_on_submit():
		if int(form.code.data) != abs(hash(ran)):
			flash("Incorriect code")
		else:
			user = User(username = username, password = password, email = email)
			user.save()
			return redirect(url_for('login'))
	return render_template('verify.html', form=form)



@app.route('/login', methods=['GET', 'POST'])
def login():
	if current_user.is_authenticated:
		return redirect(url_for('index'))

	form = LoginForm()
	if form.validate_on_submit():
		user = User.objects(username=form.username.data).first()

		if user is None:
			flash("Invalid Username")
		elif not bcrypt.check_password_hash(user.password, form.password.data):
			flash("Incorrect Password")
		else:
			ran = ''.join([random.choice(string.ascii_letters + string.digits) for n in range(8)])
			return redirect(url_for('TFAlog', username = user.username, email = user.email, ran = ran))

	return render_template('login.html',form=form)


@app.route('/TFAlog/<username>/<email>/<ran>', methods=['GET', 'POST'])
def TFAlog(username,email,ran):
	if current_user.is_authenticated:
		return redirect(url_for('index'))
	form = TFAForm()
	if flask.request.method == 'GET':
		msg = Message("Verify Code", sender="ishaskekre@gmail.com", recipients=[email])
		msg.body = "Verification code: "  + str(abs(hash(ran)))      
		mail.send(msg)
	if form.validate_on_submit():
		print
		if int(form.code.data) != abs(hash(ran)):
			flash("Incorrect code")
		else:
			login_user(user = User.objects(username=username).first())
			return redirect(url_for('account'))
	return render_template('verify.html', form=form)

@app.route('/logout')
@login_required
def logout():
	logout_user()
	return redirect(url_for('index'))

@app.route('/account', methods=['GET', 'POST'])
@login_required
def account():
	form = UpdateUsernameForm()
	form2 = PostForm()
	if form.validate_on_submit():
		current_user.modify(username=form.username.data)
		current_user.save()
		return redirect(request.path)
	if form2.validate_on_submit():
		post = Post(
			poster = load_user(current_user.username),
			title = form2.title.data,
			content = form2.text.data,
			date = current_time(),
			topic = form2.topic.data,
			likes = 0
		)
		post.save()
		return redirect(url_for('index'))
	return render_template('account.html', form = form, form2 = form2)
