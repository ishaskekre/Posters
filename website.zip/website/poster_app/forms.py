from flask_login import current_user
from flask_wtf import FlaskForm
from flask_wtf.file import FileField, File
quired, FileAllowed
from werkzeug.utils import secure_filename
from wtforms import StringField, IntegerField, SubmitField, TextAreaField, PasswordField
from wtforms.validators import (InputRequired, DataRequired, NumberRange, Length, Email, 
                                EqualTo, ValidationError)

from .models import User, Post
import re
class PostForm(FlaskForm):
    title = TextAreaField('Title', validators=[InputRequired(), Length(min=5, max=100)])
    text = TextAreaField('Post', validators=[InputRequired(), Length(min=1, max=500)])
    topic = TextAreaField('Topic', validators=[InputRequired()])
    submit = SubmitField('Enter Post')

    def validate_title(self, title):
        post = Post.objects(title=title.data).first()
        if post is not None:
            raise ValidationError('Title is taken')

    def validate_topic(self, topic):
        top = topic.data
        if top != 'S:
            raise ValidationError('Invalid Topic')

class CommentForm(FlaskForm):
    text = TextAreaField('Comment', validators=[InputRequired(), Length(min=1, max=500)])
    submit = SubmitField('Enter Comment')

class LikeForm(FlaskForm):
    submit = SubmitField('Like')

class RegistrationForm(FlaskForm):
    username = StringField('Username', validators=[InputRequired(), Length(min=1, max=40)])
    email = StringField('Email', validators=[InputRequired(), Email()])
    password = PasswordField('Password', validators=[InputRequired(), Length(min=8)])
    confirm_password = PasswordField('Confirm Password', 
                                    validators=[InputRequired(), EqualTo('password')])
    submit = SubmitField('Sign Up')

    def validate_username(self, username):
        user = User.objects(username=username.data).first()
        if user is not None:
            raise ValidationError('Username is taken')

    def validate_email(self, email):        
        user = User.objects(email=email.data).first()
        if user is not None:
            raise ValidationError('Email is taken')
    def validate_password(self, password):  
        pwd = password.data
        sp = re.compile('[@_!#$%^&*()<>?/\|}{~:]')
        upper = re.compile('[A-Z]')
        if sp.search(pwd) == None or upper.search(pwd) == None:
            raise ValidationError('Password must contain a special character and an upper-case letter')

class TFAForm(FlaskForm):
    code = IntegerField('Code')
    submit = SubmitField('Verify')

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[InputRequired(), Length(min=1, max=40)])
    password = PasswordField('Password', validators=[InputRequired()])
    submit = SubmitField('Login')

class UpdateUsernameForm(FlaskForm):
    username = StringField('Username', validators=[InputRequired(), Length(min=1, max=40)])
    submit = SubmitField('Update')

    def validate_username(self, username):
        user = User.objects(username=username.data).first()
        if user is not None:
            raise ValidationError('Username is taken')
